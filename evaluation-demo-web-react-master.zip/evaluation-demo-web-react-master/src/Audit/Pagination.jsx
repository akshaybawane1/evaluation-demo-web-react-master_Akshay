import React from "react"
import { useEffect } from "react"
import { useState } from "react"
let TF_Format = []
const Pages = ({ users, handleDeleteUser }) => {
  if (users.loading) {
    return <em>Loading users...</em>
  }
  const [myUsers, setMyUsers] = useState([...users.items])
  const [sortOrder, setSortOrder] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [userPerPage, setUserPerPage] = useState(10)
  const [firstLoad, setFirstLoad] = useState(true)

  useEffect(() => {
    setFirstLoad(false)
  }, [])

  if (firstLoad) {
    myUsers.map(user => {
      const [y, m, d] = user.createdDate.split("T")[0].split("-")
      const newTime = user.createdDate.split("T")[1].substring(0, 8)
      const newDate = [d, m, y].join("/") + " " + newTime
//       console.log(newDate)
      TF_Format.push({...user,createdDate:newDate})
      user.createdDate = newDate
    })

  }
// console.log(TF_Format)
  const changeFormat = ()=>{
        const newFormat = myUsers.map(user => {
                // const [y, m, d] = user.createdDate.split("T")[0].split("-")
                let hours = user.createdDate.split(" ")[1].substring(0, 2)
                let [mm,ss] = user.createdDate.split(" ")[1].substring(3, 8).split(":")
                const hrs = hours
                if(hours > 12){
                        hours = hours - 12
                }

                let newTime = [hours,mm,ss].join(":")
                if(newTime.length == 7){
                        newTime = "0"+newTime
                }
                if(hrs > 12){
                        newTime = newTime + "PM"
                }else{
                        newTime = newTime + "AM"    
                }
                
                // console.log(newTime)

                const date = user.createdDate.split(" ")[0]
                const newDate = date +" " + newTime
                // console.log(newDate)
                const newArr = {...user,createdDate:newDate}
                return newArr
                // user.createdDate = newDate
              })
              
        //       console.log(newFormat)
              setMyUsers(newFormat)
  }

  const lastUserInd = currentPage * userPerPage
  const firstUserInd = lastUserInd - userPerPage
  const currentUsers = myUsers.slice(firstUserInd, lastUserInd)

  const pageNumbers = []

  for (let i = 1; i <= Math.ceil(users.items.length / userPerPage); i++) {
    pageNumbers.push(i)
  }

  const SortByName = () => {
    const SortArr = (a, b) => {
      if (!sortOrder) {
        if (a.firstName < b.firstName) {
          return -1
        }
        if (a.firstName > b.firstName) {
          return 1
        }
      } else {
        if (a.firstName > b.firstName) {
          return -1
        }
        if (a.firstName < b.firstName) {
          return 1
        }
      }

      return 0
    }
    const sortedArr = myUsers.sort(SortArr)
    setMyUsers([...sortedArr])
    setSortOrder(!sortOrder)
  }

  const hangleSearch = e => {
    if (e.target.value === "") {
      setMyUsers([...users.items])
      return
    }
    console.log(e.target.value)
    const newArr = myUsers.filter(item => {
      if (item.firstName.includes(e.target.value)) {
        return item
      }
    })

    setMyUsers(newArr)
  }

  const styleObj = {
    padding: "6px",
    borderRadius: "5px",
    marginLeft: "4px",
    marginRight: "4px",
    border: "none"
  }

  return (
    <div>
        <div style={{"width":"100%","display":"flex","flexDirection":"row"}}>
      <button type="button" className="btn btn-success" onClick={SortByName}>
        Sort by FirstName
      </button>
      <input type="text" style={styleObj} placeholder="Search By Name" onChange={hangleSearch} />

      <div className="dropdown">
        <button className="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
          Change Time Format
        </button>
        <ul className="dropdown-menu">
          <li>
            <a className="dropdown-item" onClick={changeFormat}>
              12 Hr
            </a>
          </li>
          <li>
            <a className="dropdown-item" onClick={()=>setMyUsers([...TF_Format])}>
              24 Hr
            </a>
          </li>
        </ul>
      </div>
      </div>
      <table className="display table table-fluid" style={{ width: "100%" }} id="table_id">
        <thead>
          <tr>
            <th>Id</th>
            <th>Role</th>
            <th>Created Date</th>
            <th>firstName</th>
            <th>lastName</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          {currentUsers.map((user, index) => {
            return (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.role}</td>
                <td>{user.createdDate}</td>
                <td>{user.firstName}</td>
                <td>{user.lastName}</td>
                <td>
                  {user.deleting ? (
                    <em> - Deleting...</em>
                  ) : user.deleteError ? (
                    <span className="text-danger"> - ERROR: {user.deleteError}</span>
                  ) : (
                    <span>
                      {" "}
                      <a onClick={handleDeleteUser(user.id)}>Delete</a>
                    </span>
                  )}
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>

      <nav>
        <ul className="pagination">
          {pageNumbers.map(num => {
            return (
              <li key={num} className="page-item">
                <a className="page-link" onClick={() => setCurrentPage(num)}>
                  {num}
                </a>
              </li>
            )
          })}
        </ul>
      </nav>
    </div>
  )
}

export default Pages
